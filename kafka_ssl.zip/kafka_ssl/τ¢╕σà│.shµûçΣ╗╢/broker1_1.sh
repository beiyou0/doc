#!/bin/bash

rm -rf /mnt/disk/huxitest/certificates

mkdir -p /mnt/disk/huxitest/certificates

cd /mnt/disk/huxitest/certificates



# 生成自己的证书，并放到keystore中；
keytool -keystore server.keystore.jks -alias 9.111.221.101 -validity 365 -genkey -keyalg RSA -storepass kafka1234567 -keypass kafka1234567 -dname "CN=Xi Hu, OU=esb, O=ibm, L=beijing, ST=beijing, C=CN"

# 生成一个CA
openssl req -new -x509 -keyout ca-key -out ca-cert -days 365 -passin pass:"kafka1234567" -passout pass:"kafka1234567" -subj "/C=CN/ST=beijing/L=beijing/OU=esb/O=ibm/CN=Xi Hu"	

# 把证书从keystore中拿出来，准备签字
keytool -keystore server.keystore.jks -alias 9.111.221.101 -certreq -file cert-file -storepass kafka1234567 -keypass kafka1234567


# 用CA给自己的证书签字
openssl x509 -req -CA ca-cert -CAkey ca-key -in cert-file -out cert-9.111.221.101-signed -days 365 -CAcreateserial -passin pass:kafka1234567 




# 将CA放进truststore中
keytool -keystore server.truststore.jks -alias CARoot -import -file ca-cert -storepass kafka1234567 -keypass kafka1234567

# 将签完名之后的自己的证书放进truststore中
keytool -keystore server.truststore.jks -alias 9.111.221.101 -import -file cert-9.111.221.101-signed -storepass kafka1234567 -keypass kafka1234567