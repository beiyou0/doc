#!/bin/bash

cd /mnt/disk/huxitest/certificates

cp server.truststore.jks client.truststore.jks

rm server.truststore.jks