#!/bin/bash

cd /mnt/disk/huxitest/certificates 

keytool -keystore server.truststore.jks -alias 9.111.221.106 -import -file cert-9.111.221.106-signed -storepass kafka1234567 -keypass kafka1234567
keytool -keystore server.truststore.jks -alias 9.111.215.104 -import -file cert-9.111.215.104-signed -storepass kafka1234567 -keypass kafka1234567
keytool -keystore server.truststore.jks -alias 9.111.212.148 -import -file cert-9.111.212.148-signed -storepass kafka1234567 -keypass kafka1234567