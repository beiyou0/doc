#!/bin/bash

cd /mnt/disk/huxitest/certificates

openssl x509 -req -CA ca-cert -CAkey ca-key -in cert-file -out cert-9.111.215.104-signed -days 365 -CAcreateserial -passin pass:kafka1234567 