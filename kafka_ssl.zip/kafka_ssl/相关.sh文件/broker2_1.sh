#!/bin/bash

rm -rf /mnt/disk/huxitest/certificates

mkdir -p /mnt/disk/huxitest/certificates

cd /mnt/disk/huxitest/certificates



# 生成自己的证书，并放到keystore中；
keytool -keystore server.keystore.jks -alias 9.111.221.106 -validity 365 -genkey -keyalg RSA -storepass kafka1234567 -keypass kafka1234567 -dname "CN=Xi Hu, OU=esb, O=ibm, L=beijing, ST=beijing, C=CN"
	

# 把证书从keystore中拿出来，准备签字
keytool -keystore server.keystore.jks -alias 9.111.221.106 -certreq -file cert-file -storepass kafka1234567 -keypass kafka1234567

