#!/bin/bash

nohup java -jar kafkaTesting-1.0-SNAPSHOT.jar &
