/*
* ###############################################
*
* File Name: GrinderReporter.java
* Author: Gao Yang
* Date: 07-15-2015
* Version: 1.0
*
* Functionality: It's java code to parse agent* log from Grinder for test metrics, and generate a readable report
* Usage: java -cp <configured class path> com.ibm.cbt.performance.grinder.GrinderReporter <log dir> <output dir> <stats interval>
*
* ###############################################
*/
package com.ibm.cbt.performance.grinder;

import java.awt.Color;
import java.awt.BasicStroke;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
import java.lang.Long;

import javax.imageio.ImageIO;


/*
import org.apache.log4j.Logger;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.DatasetRenderingOrder;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
*/
import org.jfree.chart.JFreeChart;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.StandardXYItemRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;




/* Begin: added by qq*/
import java.util.Map;
import java.nio.channels.FileChannel;
import java.io.FileInputStream;
import java.io.FileOutputStream;
/* End: added by qq*/



@SuppressWarnings("unchecked")
public class GrinderReporter {

	/**
	 * @param args
	 */

	private static HashMap<String, TreeMap> apiStatsByName = new HashMap<String, TreeMap>();
	private static HashMap<String, TreeMap> pageStatsByName = new HashMap<String, TreeMap>();
	private static HashMap<String, TreeMap> tranStatsByName = new HashMap<String, TreeMap>();
	private static int statsInterval = 1;
	private static long startTimestamp = 0;
	private static SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	private static HashMap<String, APIStatsPoint> apiSummary = new HashMap<String, APIStatsPoint>();
	private static HashMap<String, PageStatsPoint> pageSummary = new HashMap<String, PageStatsPoint>();
	private static HashMap<String, TranStatsPoint> tranSummary = new HashMap<String, TranStatsPoint>();

	
	public static void main(String[] args) throws IOException, ParseException {
		// args list - args[0] -- log directory path
		//			   args[1] -- report directory path
		//			   args[2] -- statistics interval in second
		
		//Get the folder of logs to parse
		String folderToRead = "";
		String folderToWrite = "";
		try {
			folderToRead = args[0];
			folderToWrite = args[1];
			statsInterval=Integer.parseInt(args[2])*1000;
		} catch (ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
		}
		
		//Get a list of files
		File folderRead = new File(folderToRead);
		File folderWrite = new File(folderToWrite);
		if(! folderRead.isDirectory() || ! folderWrite.isDirectory()) {
			throw (new IllegalArgumentException("Input arugements should contain valid directory\n"));
		}
		File[] files = folderRead.listFiles();
		ArrayList<File> fileReadList = new ArrayList<File>();
		for (int i=0; i<files.length; i++) {
			if(files[i].getName().contains("agent")) {
				fileReadList.add(files[i]);
			}
		}
		
		Iterator<File> i = fileReadList.iterator();
		while(i.hasNext()) {
			File f = i.next();
			BufferedReader br = new BufferedReader(new FileReader(f));
			String line="";
			while((line = br.readLine())!=null) {
				if(startTimestamp == 0 && line.contains("INFO")) {
					startTimestamp = format.parse(line.substring(0, line.indexOf(',')).trim()).getTime();
				}
				if(line.contains("APISTATS")) {
					APIStatsPoint a = parseAPILine(line);
					updateAPITimeline(a);
					updateAPISummary(a);
					
				}else if(line.contains("PAGESTATS")) {
					PageStatsPoint p = parsePageLine(line);
					updatePageTimeline(p);
					updatePageSummary(p);
				}else if(line.contains("TRANSTATS")) {
					TranStatsPoint t = parseTranLine(line);
					updateTranTimeline(t);
					updateTranSummary(t);
				}
			}
			br.close();
		}

		File imgFolder = new File(folderWrite.getAbsolutePath() + File.separator + "img");
		if (!imgFolder.exists() && !imgFolder.isDirectory()) {
			imgFolder.mkdir();
		}
		for (String s : apiStatsByName.keySet()) {
			String graphFile = imgFolder.getAbsolutePath() + File.separator + "API_" + s + "_avg.png";
			XYDataset dataset = createXYDataset(s, apiStatsByName.get(s), 0, 0);
			JFreeChart chart = createXYChart(dataset, s + " Avg Response Times", "Time", "Resp. (ms)");
			BufferedImage imageMin = chart.createBufferedImage(800, 600);
			ImageIO.write(imageMin, "png", new File(graphFile));
			
			graphFile = imgFolder.getAbsolutePath() + File.separator + "API_" + s + "_tps.png";
			dataset = createXYDataset(s, apiStatsByName.get(s), 0, 1);
			chart = createXYChart(dataset, s + " Throughput (tps)", "Time", "tps");
			imageMin = chart.createBufferedImage(800, 600);
			ImageIO.write(imageMin, "png", new File(graphFile));
		}
		
		for (String s : pageStatsByName.keySet()) {
			String graphFile = imgFolder.getAbsolutePath() + File.separator + "Page_" + s + "_avg.png";
			XYDataset dataset = createXYDataset(s, pageStatsByName.get(s), 1, 0);
			JFreeChart chart = createXYChart(dataset, s + " Avg Response Times", "Time", "Resp. (ms)");
			BufferedImage imageMin = chart.createBufferedImage(800, 600);
			ImageIO.write(imageMin, "png", new File(graphFile));
			
			graphFile = imgFolder.getAbsolutePath() + File.separator + "Page_" + s + "_tps.png";
			dataset = createXYDataset(s, pageStatsByName.get(s), 1, 1);
			chart = createXYChart(dataset, s + " Throughput (tps)", "Time", "tps");
			imageMin = chart.createBufferedImage(800, 600);
			ImageIO.write(imageMin, "png", new File(graphFile));
		}
		
		for (String s : tranStatsByName.keySet()) {
			String graphFile = imgFolder.getAbsolutePath() + File.separator + "TRAN_" + s + "_tps.png";
			XYDataset dataset = createXYDataset(s, tranStatsByName.get(s), 2, 1);
			JFreeChart chart = createXYChart(dataset, s + " Throughput (tps)", "Time", "tps");
			BufferedImage imageMin = chart.createBufferedImage(800, 600);
			ImageIO.write(imageMin, "png", new File(graphFile));
		}
		BufferedWriter bw = new BufferedWriter(new FileWriter(folderToWrite+"/summary"));
		bw.write("Name,Success,Fails,tps,Avg Response\n");
		for(String s : tranSummary.keySet()) {
			bw.write(s+","+tranSummary.get(s).success+","+tranSummary.get(s).error+","+tranSummary.get(s).tps+"\n");
		}
		for(String s : pageSummary.keySet()) {
			bw.write(s+","+pageSummary.get(s).success+","+pageSummary.get(s).error+","+pageSummary.get(s).tps+","+pageSummary.get(s).avg+"\n");
		}
		for(String s : apiSummary.keySet()) {
			bw.write(s+","+apiSummary.get(s).success+","+apiSummary.get(s).error+","+apiSummary.get(s).tps+","+apiSummary.get(s).avg+"\n");
		}
		bw.close();
		
		generateHTMLReport(folderWrite, apiSummary, pageSummary, tranSummary);
	}
	
	private static void updateTranSummary(TranStatsPoint a) {
		// TODO Auto-generated method stub
		if (tranSummary.get(a.name) == null) {
			tranSummary.put(a.name, new TranStatsPoint());
		}
		TranStatsPoint point = tranSummary.get(a.name);
		point.success += a.success;
		point.error += a.error;
		point.err_rate = (double)point.error/(point.success+point.error);
		point.tps = (double)point.success/(a.time-startTimestamp)*1000;	
	}

	private static void updateTranTimeline(TranStatsPoint a) {
		// TODO Auto-generated method stub
		if (tranStatsByName.get(a.name) == null) {
			tranStatsByName.put(a.name, new TreeMap<Long, TranStatsPoint>());
		}
		TreeMap<Long, TranStatsPoint> timeline = tranStatsByName.get(a.name);
		TranStatsPoint point = null;
		if (timeline.isEmpty() || a.time > timeline.lastKey() + statsInterval){
			point = new TranStatsPoint(a);
			point.tps = (double)point.success/(point.time-startTimestamp)*1000;
			timeline.put(point.time, point);
		}else if (a.time <= timeline.lastKey() + statsInterval && timeline.keySet().size() == 1) {
			point = timeline.get(timeline.lastKey());
			point.success += a.success;
			point.error += a.error;
			point.err_rate = (double)point.error/(point.success+point.error);
			point.tps = (double)point.success/(timeline.lastKey()-startTimestamp)*1000;
		}else if (a.time <= timeline.lastKey() + statsInterval && timeline.keySet().size() > 1) {
			point = timeline.get(timeline.lastKey());
			Long lastTimestampPoint = (Long)(timeline.descendingKeySet().toArray()[1]);
			point.success += a.success;
			point.error += a.error;
			point.err_rate = (double)point.error/(point.success+point.error);
			point.tps = (double)point.success/(timeline.lastKey()-lastTimestampPoint)*1000;
		}
		
	}

	private static void updatePageSummary(PageStatsPoint a) {
		// TODO Auto-generated method stub
		if (pageSummary.get(a.name) == null) {
			pageSummary.put(a.name, new PageStatsPoint());
		}
		PageStatsPoint point = pageSummary.get(a.name);
		if(point.min>a.min) {
			point.min=a.min;
		}
		if(point.max<a.max){
			point.max=a.max;
		}
		point.avg = (point.avg*point.success+a.avg*a.success)/(point.success+a.success);
		point.std = (Math.pow(point.std, 2)*point.success + Math.pow(a.avg-point.avg, 2))/(point.success+a.success);
		point.success += a.success;
		point.error += a.error;
		point.err_rate = (double)point.error/(point.success+point.error);
		point.tps = (double)point.success/(a.time-startTimestamp)*1000;	
	}

	private static void updatePageTimeline(PageStatsPoint a) {
		// TODO Auto-generated method stub
		if (pageStatsByName.get(a.name) == null) {
			pageStatsByName.put(a.name, new TreeMap<Long, PageStatsPoint>());
		}
		TreeMap<Long, PageStatsPoint> timeline = pageStatsByName.get(a.name);
		PageStatsPoint point = null;
		if (timeline.isEmpty() || a.time > timeline.lastKey() + statsInterval){
			point = new PageStatsPoint(a);
			point.tps = (double)point.success/(point.time-startTimestamp)*1000;
			timeline.put(point.time, point);
		}else if (a.time <= timeline.lastKey() + statsInterval && timeline.keySet().size() == 1) {
			point = timeline.get(timeline.lastKey());
			if(point.min>a.min) {
				point.min=a.min;
			}
			if(point.max<a.max){
				point.max=a.max;
			}
			point.avg = (point.avg*point.success+a.avg*a.success)/(point.success+a.success);
			point.std = Math.sqrt((Math.pow(point.std, 2)*point.success + Math.pow(a.avg-point.avg, 2))/(point.success+a.success));
			point.success += a.success;
			point.error += a.error;
			point.err_rate = (double)point.error/(point.success+point.error);
			point.tps = (double)point.success/(timeline.lastKey()-startTimestamp)*1000;
		}else if (a.time <= timeline.lastKey() + statsInterval && timeline.keySet().size() > 1) {
			point = timeline.get(timeline.lastKey());
			Long lastTimestampPoint = (Long)(timeline.descendingKeySet().toArray()[1]);
			if(point.max<a.max){
				point.max=a.max;
			}
			point.avg = (point.avg*point.success+a.avg*a.success)/(point.success+a.success);
			point.std = Math.sqrt((Math.pow(point.std, 2)*point.success + Math.pow(a.avg-point.avg, 2))/(point.success+a.success));
			point.success += a.success;
			point.error += a.error;
			point.err_rate = (double)point.error/(point.success+point.error);
			point.tps = (double)point.success/(timeline.lastKey()-lastTimestampPoint)*1000;
		}
		
	}

	private static void updateAPISummary(APIStatsPoint a) {
		// TODO Auto-generated method stub
		
		if (apiSummary.get(a.name) == null) {
			apiSummary.put(a.name, new APIStatsPoint());
		}
		APIStatsPoint point = apiSummary.get(a.name);
		if(point.min>a.min) {
			point.min=a.min;
		}
		if(point.max<a.max){
			point.max=a.max;
		}
		point.avg = (point.avg*point.success+a.avg*a.success)/(point.success+a.success);
		point.std = Math.sqrt((Math.pow(point.std, 2)*point.success + Math.pow(a.avg-point.avg, 2))/(point.success+a.success));
		point.success += a.success;
		point.error += a.error;
		point.err_rate = (double)point.error/(point.success+point.error);
		point.tps = (double)point.success/(a.time-startTimestamp)*1000;		
	}

	private static void updateAPITimeline(APIStatsPoint a) {
		// TODO Auto-generated method stub
		
		if (apiStatsByName.get(a.name) == null) {
			apiStatsByName.put(a.name, new TreeMap<Long, APIStatsPoint>());
		}
		TreeMap<Long, APIStatsPoint> timeline = apiStatsByName.get(a.name);
		APIStatsPoint point = null;
		if (timeline.isEmpty() || a.time > timeline.lastKey() + statsInterval){
			point = new APIStatsPoint(a);
			point.tps = (double)point.success/(point.time-startTimestamp)*1000;
			timeline.put(point.time, point);
		}else if (a.time <= timeline.lastKey() + statsInterval && timeline.keySet().size() == 1) {
			point = timeline.get(timeline.lastKey());
			if(point.min>a.min) {
				point.min=a.min;
			}
			if(point.max<a.max){
				point.max=a.max;
			}
			point.avg = (point.avg*point.success+a.avg*a.success)/(point.success+a.success);
			point.std = Math.sqrt((Math.pow(point.std, 2)*point.success + Math.pow(a.avg-point.avg, 2))/(point.success+a.success));
			point.success += a.success;
			point.error += a.error;
			point.err_rate = (double)point.error/(point.success+point.error);
			point.tps = (double)point.success/(timeline.lastKey()-startTimestamp)*1000;
		}else if (a.time <= timeline.lastKey() + statsInterval && timeline.keySet().size() > 1) {
			point = timeline.get(timeline.lastKey());
			Long lastTimestampPoint = (Long)(timeline.descendingKeySet().toArray()[1]);	
			if(point.min>a.min) {
				point.min=a.min;
			}
			if(point.max<a.max){
				point.max=a.max;
			}
			point.avg = (point.avg*point.success+a.avg*a.success)/(point.success+a.success);
			point.std = Math.sqrt((Math.pow(point.std, 2)*point.success + Math.pow(a.avg-point.avg, 2))/(point.success+a.success));
			point.success += a.success;
			point.error += a.error;
			point.err_rate = (double)point.error/(point.success+point.error);
			point.tps = (double)point.success/(timeline.lastKey()-lastTimestampPoint)*1000;
		}
		
	}
	
	//2015-07-12 20:25:11,500 [thread 6] INFO - APISTATS:API1:-1-1-6:91.79,91.79,91.79,0.0,1,0
	// Format: Timestamp [ thread #] INFO - APISTATS:<API_NAME>:<Agent-Process-Thread>:min,max,avg,std,sucess,error
	private static APIStatsPoint parseAPILine(String line) {
		
		APIStatsPoint a = new APIStatsPoint();
		try {
			a.time = format.parse(line.substring(0, line.indexOf(',')).trim()).getTime();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String[] s = line.substring(line.indexOf("APISTATS:")).split(":");
		a.name = s[1];
		String[] s1 = s[3].split(",");
		a.min = Double.parseDouble(s1[0]);
		a.max = Double.parseDouble(s1[1]);
		a.avg = Double.parseDouble(s1[2]);
		a.std = Double.parseDouble(s1[3]);
		a.success=Integer.parseInt(s1[4]);
		a.error=Integer.parseInt(s1[5]);
		a.err_rate=(double)a.success/(a.success+a.error);
		
		return a;
	}
	
	//2015-07-12 20:25:11,500 [thread 6] INFO - PAGESTATS:Page1:-1-1-6:107.61,107.61,107.61,0.0,1,0
	// Format: Timestamp [ thread #] INFO - PAGESTATS:<PAGE_NAME>:<Agent-Process-Thread>:min,max,avg,std,sucess,error
	private static PageStatsPoint parsePageLine(String line) {
		
		PageStatsPoint p = new PageStatsPoint();
		try {
			p.time = format.parse(line.substring(0, line.indexOf(',')).trim()).getTime();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String[] s = line.substring(line.indexOf("PAGESTATS:")).split(":");
		p.name = s[1];
		String[] s1 = s[3].split(",");
		p.min = Double.parseDouble(s1[0]);
		p.max = Double.parseDouble(s1[1]);
		p.avg = Double.parseDouble(s1[2]);
		p.std = Double.parseDouble(s1[3]);
		p.success=Integer.parseInt(s1[4]);
		p.error=Integer.parseInt(s1[5]);
		p.err_rate=(double)p.success/(p.success+p.error);
		
		return p;
	}
	
	//2015-07-12 20:25:11,500 [thread 3] INFO - TRANSTATS:Trans2:-1-1-3:1,0
	// Format: Timestamp [ thread #] INFO - TRANSTATS:<TRAN_NAME>:<Agent-Process-Thread>:sucess,error
	private static TranStatsPoint parseTranLine(String line) {
		
		TranStatsPoint t = new TranStatsPoint();
		try {
			t.time = format.parse(line.substring(0, line.indexOf(',')).trim()).getTime();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String[] s = line.substring(line.indexOf("TRANSTATS:")).split(":");
		t.name = s[1];
		String[] s1 = s[3].split(",");
		t.success=Integer.parseInt(s1[0]);
		t.error=Integer.parseInt(s1[1]);
		t.err_rate=(double)t.success/(t.success+t.error);
		
		return t;
	}
	
	private static JFreeChart createXYChart(final XYDataset dataset, String title, String xaxis, String yaxis) {

		final JFreeChart chart = ChartFactory.createTimeSeriesChart(title, xaxis, yaxis, dataset, true, true, false);
		
		final XYPlot plot = chart.getXYPlot();
		plot.setBackgroundPaint(Color.white);
		plot.setDomainGridlinePaint(Color.lightGray);
		plot.setRangeGridlinePaint(Color.lightGray);
		plot.setDomainCrosshairVisible(true);
		plot.setRangeCrosshairVisible(false);
		
		final XYItemRenderer renderer = plot.getRenderer();
		if (renderer instanceof StandardXYItemRenderer) {
			renderer.setSeriesStroke(0, new BasicStroke(2.0f));
			renderer.setSeriesStroke(1, new BasicStroke(2.0f));
		}
		
		final DateAxis axis = (DateAxis) plot.getDomainAxis();
		axis.setVerticalTickLabels(true);
		axis.setDateFormatOverride(new SimpleDateFormat("yyyy-MM-dd HH:mm"));
		
		return chart;

	}
	
	/* 
	 * datatype 0 -- api, 1 -- page, 2 -- transaction
	 * valueToUse 0 -- avg response time, 1 -- tps
	 */
	private static XYDataset createXYDataset(String legend, TreeMap<Long, Object> timeline, int datatype, int valueToUse) {
		
		final TimeSeriesCollection dataset = new TimeSeriesCollection();
		TimeSeries s1 = new TimeSeries(legend);
		Iterator<Long> timeSet = timeline.keySet().iterator();
		
		while(timeSet.hasNext()) {
			Long timestamp = timeSet.next();
			String time = format.format(new Date(timestamp)); //yyyy-MM-dd HH:mm:ss
			int year = Integer.parseInt(time.substring(0, 4));
			int month = Integer.parseInt(time.substring(5, 7));
			int day = Integer.parseInt(time.substring(8, 10));
			int hour = Integer.parseInt(time.substring(11, 13));
			int minute = Integer.parseInt(time.substring(14, 16));
			int second = Integer.parseInt(time.substring(17, 19));
			
			switch(datatype) {
			
			case 0:
				APIStatsPoint a = (APIStatsPoint)timeline.get(timestamp);
				switch(valueToUse) {
				case 0:					
					s1.addOrUpdate(new Second(second, minute, hour, day, month, year), a.avg);	
					break;
				case 1:
					s1.addOrUpdate(new Second(second, minute, hour, day, month, year), a.tps);	
					break;
				}
				break;
			case 1:
				PageStatsPoint p = (PageStatsPoint)timeline.get(timestamp);
				switch(valueToUse) {
				case 0:					
					s1.addOrUpdate(new Second(second, minute, hour, day, month, year), p.avg);	
					break;
				case 1:
					s1.addOrUpdate(new Second(second, minute, hour, day, month, year), p.tps);	
					break;
				}
				break;
			case 2:
				TranStatsPoint t = (TranStatsPoint)timeline.get(timestamp);
				switch(valueToUse) {
				case 0:
					break;
				case 1:
					s1.addOrUpdate(new Second(second, minute, hour, day, month, year), t.tps);	
					break;
				}
				break;
			}
		}
		dataset.addSeries(s1);
		return dataset;
	}
	
	/*Begin: added by qq*/
	private static void copyFileByFileChannel(File src, File dst) throws IOException{
		FileChannel inputChannel = null;
		FileChannel outputChannel = null;
		
		try {
			inputChannel = new FileInputStream(src).getChannel();
			outputChannel = new FileOutputStream(dst).getChannel();
			outputChannel.transferFrom(inputChannel, 0, inputChannel.size());
			
		} finally {
			inputChannel.close();
			outputChannel.close();
		}
	}
	
	private static void generateHTMLReport(File folderToWrite, HashMap<String, APIStatsPoint> apiSummary, 
						HashMap<String, PageStatsPoint> pageSummary, HashMap<String, TranStatsPoint> tranSummary) throws IOException {
		File templateFolder = new File("template");
		File[] files = templateFolder.listFiles();
		for (File file: files) {
			if (file.getName().indexOf(".js") != -1) {
				File jsFolder = new File(folderToWrite.getAbsolutePath() + File.separator + "js");
				if (!jsFolder.exists() && !jsFolder.isDirectory()) {
					jsFolder.mkdir();
				}
				File jsFile = new File(jsFolder.getAbsolutePath() + File.separator + file.getName());
				copyFileByFileChannel(file, jsFile);	
			}
			else if (file.getName().indexOf(".css") != -1) {
				File cssFolder = new File(folderToWrite + File.separator + "css");
				if (!cssFolder.exists() && !cssFolder.isDirectory()) {
					cssFolder.mkdir();
				}
				File cssFile = new File(cssFolder.getAbsolutePath() + File.separator + file.getName());
				copyFileByFileChannel(file, cssFile);
			}
			else {
				File htmlFile = new File(folderToWrite.getAbsolutePath() + File.separator + file.getName());
				copyFileByFileChannel(file, htmlFile);
			}
		}
		
		updateMetricJsonString(folderToWrite, apiSummary, pageSummary, tranSummary);
		System.out.println("Now, you can use report.html to check your performance report.");
	}
	
	private static void updateMetricJsonString(File folderToWrite, HashMap<String, APIStatsPoint> apiSummary, 
							HashMap<String, PageStatsPoint> pageSummary, HashMap<String, TranStatsPoint> tranSummary) throws IOException {
		String apiList = "";
		for(String s : apiSummary.keySet()) {
			String api = "{" + "\"api\":" + "\"" + s + "\"" + ","
					   + "\"success\":" + "\"" +  apiSummary.get(s).success + "\"" + ","
					   + "\"fail\":" + "\"" +  apiSummary.get(s).error + "\"" + ","
			           + "\"tps\":" + "\"" +  String.format("%.2f", apiSummary.get(s).tps) + "\"" + ","
			           + "\"avg\":" + "\"" +  String.format("%.2f", apiSummary.get(s).avg) + "\"" + ","
			           + "\"std\":" + "\"" +  String.format("%.2f", apiSummary.get(s).std) + "\"" + "},";
			apiList += api;
		}
		
		String pageList = "";
		for(String s : pageSummary.keySet()) {
			String page = "{" + "\"page\":" + "\"" + s + "\"" + ","
					   + "\"success\":" + "\"" +  pageSummary.get(s).success + "\"" + ","
					   + "\"fail\":" + "\"" +  pageSummary.get(s).error + "\"" + ","
			           + "\"tps\":" + "\"" +  String.format("%.2f", pageSummary.get(s).tps) + "\"" + ","
			           + "\"avg\":" + "\"" +  String.format("%.2f", pageSummary.get(s).avg)+ "\"" + ","
			           + "\"std\":" + "\"" +  String.format("%.2f", pageSummary.get(s).std) + "\"" + "},";
			pageList += page;
		}

		String transList = "";
		for(String s : tranSummary.keySet()) {
			String trans = "{" + "\"trans\":" + "\"" + s + "\"" + ","
					     + "\"success\":" + "\"" + tranSummary.get(s).success + "\"" + ","
					     + "\"fail\":" + "\"" + tranSummary.get(s).error + "\"" + ","
			             + "\"tps\":" + "\"" + String.format("%.2f", tranSummary.get(s).tps) + "\"" + "},";
			transList += trans;
		}
		
		HashMap<String, String> replaceProp = new HashMap<String, String>();
		replaceProp.put("@apilist@", apiList);
		replaceProp.put("@pagelist@", pageList);
		replaceProp.put("@translist@", transList);
		
		String reportFile = folderToWrite.getAbsolutePath() + File.separator + "report.html";
		File reportHTML = new File(reportFile);
		assert(reportHTML.exists());
		replaceOneFile(reportHTML, replaceProp);
	}
	
	public static void replaceOneFile(File oneFile, Map<String, String> p) throws IOException {
		File newFile = new File(oneFile.getAbsolutePath() + "-new");
		BufferedReader br = new BufferedReader(new FileReader(oneFile));
		BufferedWriter bw = new BufferedWriter(new FileWriter(newFile));
		
		String line = br.readLine();
		while(line != null) {
			for(String k: p.keySet()){
				String v = p.get(k);
				line = line.replace(k, v);
			}
			bw.write(line + "\n");
			line = br.readLine();
		}
		
		bw.flush();
		bw.close();
		br.close();
		
		if (oneFile.exists()) {
			oneFile.delete();
		}
		if (newFile.exists()) {
			newFile.renameTo(oneFile);
		}
	}
	/*End: added by qq*/
	
	static class APIStatsPoint {
		public long time=0;
		public double min=9999.0;
		public double max=0.0;
		public double avg=0.0;
		public double std=0.0;
		public int success=0;
		public int error=0;
		public double tps=0.0;
		public double err_rate=0.0;
		public String name="";
		
		public APIStatsPoint(APIStatsPoint a) {
			this.time=a.time;
			this.min=a.min;
			this.max=a.max;
			this.avg=a.avg;
			this.std=a.std;
			this.success=a.success;
			this.tps=a.tps;
			this.err_rate=a.err_rate;
			this.name=a.name;
		}
		
		public APIStatsPoint() {
			
		}
	}
	
	static class PageStatsPoint {
		public long time=0;
		public double min=0.0;
		public double max=9999.0;
		public double avg=0.0;
		public double std=0.0;
		public int success=0;
		public int error=0;
		public double tps=0.0;
		public double err_rate=0.0;
		public String name="";
		
		public PageStatsPoint(PageStatsPoint a) {
			this.time=a.time;
			this.min=a.min;
			this.max=a.max;
			this.avg=a.avg;
			this.std=a.std;
			this.success=a.success;
			this.tps=a.tps;
			this.err_rate=a.err_rate;
			this.name=a.name;
		}
		
		public PageStatsPoint() {
			
		}
	}
	
	static class TranStatsPoint {
		public long time=0;
		public int success=0;
		public int error=0;
		public double tps=0.0;
		public double err_rate=0.0;
		public String name="";
		
		public TranStatsPoint(TranStatsPoint a) {
			this.time=a.time;
			this.success=a.success;
			this.tps=a.tps;
			this.err_rate=a.err_rate;
			this.name=a.name;
		}
		
		public TranStatsPoint() {
			
		}
		
	}
}
